import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Send, Image as ImageIcon, Mic, Paperclip, MoreVertical, Trash2, RotateCcw, User as UserIcon, Bot, Sparkles } from 'lucide-react';
import { GoogleGenAI } from "@google/genai";
import ReactMarkdown from 'react-markdown';
import { cn } from '../lib/utils';
import { auth, db } from '../firebase';
import { collection, addDoc, query, orderBy, onSnapshot, serverTimestamp, setDoc, doc } from 'firebase/firestore';
import { useDropzone } from 'react-dropzone';

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: any;
  attachments?: string[];
}

import { User } from 'firebase/auth';
import { handleFirestoreError, OperationType } from '../lib/firestoreErrorHandler';

interface ChatProps {
  user: User;
}

export default function Chat({ user }: ChatProps) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [chatId, setChatId] = useState<string | null>(null);
  const [attachments, setAttachments] = useState<File[]>([]);
  const [isRecording, setIsRecording] = useState(false);
  const [audioBlob, setAudioBlob] = useState<Blob | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const chatPath = collection(db, 'users', user.uid, 'chats', 'default', 'messages');
    const q = query(
      chatPath,
      orderBy('timestamp', 'asc')
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const msgs = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Message));
      setMessages(msgs);
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, `users/${user.uid}/chats/default/messages`);
    });

    return () => unsubscribe();
  }, [user.uid]);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' });
  }, [messages, isTyping]);

  const onDrop = (acceptedFiles: File[]) => {
    setAttachments([...attachments, ...acceptedFiles]);
  };

  const { getRootProps, getInputProps, isDragActive, open } = useDropzone({ 
    onDrop,
    accept: { 
      'image/*': [],
      'audio/*': [],
      'application/pdf': [],
      'text/*': []
    },
    noClick: true
  });

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      
      const chunks: Blob[] = [];
      mediaRecorder.ondataavailable = (e) => chunks.push(e.data);
      mediaRecorder.onstop = () => {
        const blob = new Blob(chunks, { type: 'audio/webm' });
        setAudioBlob(blob);
        stream.getTracks().forEach(track => track.stop());
      };

      mediaRecorder.start();
      setIsRecording(true);
    } catch (err) {
      console.error("Error accessing microphone:", err);
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
    }
  };

  const sendMessage = async () => {
    if ((!input.trim() && attachments.length === 0 && !audioBlob) || !auth.currentUser) return;

    const userContent = input;
    const currentAttachments = [...attachments];
    const currentAudio = audioBlob;
    
    setInput('');
    setAttachments([]);
    setAudioBlob(null);
    setIsTyping(true);

    try {
      const chatPath = collection(db, 'users', user.uid, 'chats', 'default', 'messages');
      
      // Add user message to Firestore
      await addDoc(chatPath, {
        role: 'user',
        content: userContent,
        timestamp: serverTimestamp(),
        attachments: [
          ...currentAttachments.map(f => f.name),
          ...(currentAudio ? ['voice_message.webm'] : [])
        ]
      });

      // Update parent chat document for History
      await setDoc(doc(db, 'users', user.uid, 'chats', 'default'), {
        title: userContent.slice(0, 30) + (userContent.length > 30 ? '...' : '') || 'New Chat',
        lastMessage: userContent.slice(0, 50) + (userContent.length > 50 ? '...' : ''),
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      }, { merge: true });

      // Prepare Gemini parts
      const parts: any[] = [{ text: userContent || "Analyze this media:" }];
      
      for (const file of currentAttachments) {
        const base64 = await fileToBase64(file);
        parts.push({
          inlineData: {
            mimeType: file.type,
            data: base64.split(',')[1]
          }
        });
      }

      if (currentAudio) {
        const reader = new FileReader();
        const base64Promise = new Promise<string>((resolve) => {
          reader.onloadend = () => resolve(reader.result as string);
          reader.readAsDataURL(currentAudio);
        });
        const base64 = await base64Promise;
        parts.push({
          inlineData: {
            mimeType: 'audio/webm',
            data: base64.split(',')[1]
          }
        });
      }

      // Call Gemini
      try {
        const response = await ai.models.generateContent({
          model: "gemini-2.0-flash",
          contents: { parts },
          config: {
            systemInstruction: "You are RyeenzyAI, a futuristic and highly intelligent AI assistant. Your responses should be helpful, creative, and professional. You can assist with coding, creative writing, and general knowledge. If the user sends an image or audio, analyze it carefully."
          }
        });

        const aiResponse = response.text;

        // Add AI response to Firestore
        await addDoc(chatPath, {
          role: 'assistant',
          content: aiResponse,
          timestamp: serverTimestamp()
        });
      } catch (geminiError: any) {
        console.error("Gemini Error:", geminiError);
        let errorMessage = "I encountered an error processing your request.";
        
        const errorBody = geminiError.message || "";
        if (errorBody.includes('429') || errorBody.includes('RESOURCE_EXHAUSTED')) {
          errorMessage = "Quota exceeded for the Gemini API. This usually happens on the free tier when too many requests are sent in a short time. Please wait a minute and try again, or check your API quota at https://aistudio.google.com/app/plan_and_billing";
        } else if (errorBody.includes('500')) {
          errorMessage = "The AI service is currently experiencing issues. Please try again later.";
        }

        await addDoc(chatPath, {
          role: 'assistant',
          content: `⚠️ **System Note:** ${errorMessage}`,
          timestamp: serverTimestamp()
        });
      }

    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, `users/${user.uid}/chats/default/messages`);
    } finally {
      setIsTyping(false);
    }
  };

  const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = error => reject(error);
    });
  };

  return (
    <div className="h-full flex flex-col bg-black/20 backdrop-blur-sm" {...getRootProps()}>
      <input {...getInputProps()} />
      
      {/* Header */}
      <header className="px-4 md:px-6 py-3 md:py-4 border-b border-white/10 flex items-center justify-between bg-black/40">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 md:w-10 md:h-10 rounded-full overflow-hidden border border-white/10 flex items-center justify-center">
            <img 
              src="https://www.image2url.com/r2/default/images/1776259988731-7cc679d1-4c75-4ec5-b335-ad5c748f0010.png" 
              alt="AI Logo" 
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
          </div>
          <div>
            <h2 className="font-bold text-sm md:text-base">RyeenzyAI</h2>
            <div className="flex items-center gap-1.5">
              <div className="w-1 h-1 md:w-1.5 md:h-1.5 rounded-full bg-emerald-500 animate-pulse" />
              <span className="text-[8px] md:text-[10px] text-silver/40 uppercase tracking-widest">System Online</span>
            </div>
          </div>
        </div>
        <div className="flex items-center gap-1 md:gap-2">
          <button className="p-1.5 md:p-2 hover:bg-white/5 rounded-lg text-silver/40 hover:text-white transition-colors">
            <RotateCcw className="w-3.5 h-3.5 md:w-4 md:h-4" />
          </button>
          <button className="p-1.5 md:p-2 hover:bg-white/5 rounded-lg text-silver/40 hover:text-white transition-colors">
            <MoreVertical className="w-3.5 h-3.5 md:w-4 md:h-4" />
          </button>
        </div>
      </header>

      {/* Messages */}
      <div 
        ref={scrollRef}
        className="flex-1 overflow-y-auto p-4 md:p-6 space-y-6 md:space-y-8 custom-scrollbar"
      >
        {messages.length === 0 && !isTyping && (
          <div className="h-full flex flex-col items-center justify-center text-center opacity-40 p-4">
            <Sparkles className="w-10 h-10 md:w-12 md:h-12 mb-4 text-silver" />
            <h3 className="text-lg md:text-xl font-bold mb-2">How can I help you today?</h3>
            <p className="text-xs md:text-sm max-w-xs">Ask me anything, from complex coding problems to creative storytelling.</p>
          </div>
        )}

        {messages.map((msg) => (
          <motion.div
            key={msg.id}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className={cn(
              "flex gap-3 md:gap-4 max-w-4xl mx-auto",
              msg.role === 'user' ? "flex-row-reverse" : "flex-row"
            )}
          >
            <div className={cn(
              "w-7 h-7 md:w-8 md:h-8 rounded-lg flex items-center justify-center shrink-0 overflow-hidden",
              msg.role === 'user' ? "bg-white/10" : "bg-accent/10"
            )}>
              {msg.role === 'user' ? (
                <UserIcon className="w-3.5 h-3.5 md:w-4 md:h-4" />
              ) : (
                <img 
                  src="https://www.image2url.com/r2/default/images/1776259988731-7cc679d1-4c75-4ec5-b335-ad5c748f0010.png" 
                  alt="AI" 
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              )}
            </div>
            <div className={cn(
              "space-y-2 max-w-[85%] md:max-w-[80%]",
              msg.role === 'user' ? "items-end" : "items-start"
            )}>
              <div className={cn(
                "p-3 md:p-4 rounded-2xl text-xs md:text-sm leading-relaxed",
                msg.role === 'user' 
                  ? "bg-white text-black rounded-tr-none" 
                  : "bg-white/5 border border-white/10 text-silver/90 rounded-tl-none"
              )}>
                <div className="prose prose-invert prose-xs md:prose-sm max-w-none">
                  <ReactMarkdown>
                    {msg.content}
                  </ReactMarkdown>
                </div>
              </div>
              {msg.attachments && msg.attachments.length > 0 && (
                <div className="flex flex-wrap gap-2">
                  {msg.attachments.map((att, i) => (
                    <div key={i} className="px-2 py-1 bg-white/5 border border-white/10 rounded text-[10px] text-silver/40">
                      {att}
                    </div>
                  ))}
                </div>
              )}
            </div>
          </motion.div>
        ))}

        {isTyping && (
          <div className="flex gap-4 max-w-4xl mx-auto">
            <div className="w-8 h-8 rounded-lg bg-accent/10 flex items-center justify-center shrink-0 overflow-hidden">
              <img 
                src="https://www.image2url.com/r2/default/images/1776259988731-7cc679d1-4c75-4ec5-b335-ad5c748f0010.png" 
                alt="AI" 
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
            <div className="bg-white/5 border border-white/10 p-4 rounded-2xl rounded-tl-none">
              <div className="flex gap-1">
                <motion.div animate={{ opacity: [0.3, 1, 0.3] }} transition={{ repeat: Infinity, duration: 1 }} className="w-1.5 h-1.5 bg-accent rounded-full" />
                <motion.div animate={{ opacity: [0.3, 1, 0.3] }} transition={{ repeat: Infinity, duration: 1, delay: 0.2 }} className="w-1.5 h-1.5 bg-accent rounded-full" />
                <motion.div animate={{ opacity: [0.3, 1, 0.3] }} transition={{ repeat: Infinity, duration: 1, delay: 0.4 }} className="w-1.5 h-1.5 bg-accent rounded-full" />
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Input Area */}
      <footer className="p-6 bg-black/40 border-t border-white/10">
        <div className="max-w-4xl mx-auto relative">
          { (attachments.length > 0 || audioBlob) && (
            <div className="absolute bottom-full left-0 mb-4 flex flex-wrap gap-2">
              {attachments.map((file, i) => (
                <div key={i} className="flex items-center gap-2 bg-white/10 border border-white/10 px-3 py-1.5 rounded-full text-xs">
                  <ImageIcon className="w-3 h-3" />
                  <span className="truncate max-w-[100px]">{file.name}</span>
                  <button onClick={() => setAttachments(attachments.filter((_, idx) => idx !== i))} className="hover:text-red-400">
                    <Trash2 className="w-3 h-3" />
                  </button>
                </div>
              ))}
              {audioBlob && (
                <div className="flex items-center gap-2 bg-emerald-500/20 border border-emerald-500/20 px-3 py-1.5 rounded-full text-xs text-emerald-400">
                  <Mic className="w-3 h-3" />
                  <span>Voice Message</span>
                  <button onClick={() => setAudioBlob(null)} className="hover:text-red-400">
                    <Trash2 className="w-3 h-3" />
                  </button>
                </div>
              )}
            </div>
          )}

          <div className={cn(
            "relative bg-white/5 border border-white/10 rounded-2xl p-2 transition-all duration-300",
            isDragActive && "border-silver bg-white/10 scale-[1.01]"
          )}>
            <textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  sendMessage();
                }
              }}
              placeholder={isDragActive ? "Drop images here..." : "Type your message..."}
              className="w-full bg-transparent border-none focus:ring-0 text-sm p-3 min-h-[50px] max-h-[200px] resize-none placeholder:text-silver/20"
            />
            <div className="flex items-center justify-between px-2 pb-1">
              <div className="flex items-center gap-1">
                <button 
                  onClick={() => open()}
                  className="p-2 hover:bg-white/5 rounded-lg text-silver/40 hover:text-white transition-colors"
                >
                  <Paperclip className="w-4 h-4" />
                </button>
                <button 
                  onClick={() => open()}
                  className="p-2 hover:bg-white/5 rounded-lg text-silver/40 hover:text-white transition-colors"
                >
                  <ImageIcon className="w-4 h-4" />
                </button>
                <button 
                  onMouseDown={startRecording}
                  onMouseUp={stopRecording}
                  onMouseLeave={stopRecording}
                  onTouchStart={startRecording}
                  onTouchEnd={stopRecording}
                  className={cn(
                    "p-2 rounded-lg transition-all",
                    isRecording ? "bg-red-500 text-white animate-pulse" : "hover:bg-white/5 text-silver/40 hover:text-white"
                  )}
                >
                  <Mic className="w-4 h-4" />
                </button>
              </div>
              <button
                onClick={sendMessage}
                disabled={(!input.trim() && attachments.length === 0 && !audioBlob) || isTyping}
                className="bg-accent text-black p-2.5 rounded-xl hover:opacity-90 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <Send className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
