import Spline from '@splinetool/react-spline';
import { Suspense } from 'react';

interface ThemeProps {
  type: string;
  color: string;
}

export default function ThreeBackground({ type, color }: ThemeProps) {
  return (
    <div className="fixed inset-0 -z-10 bg-black overflow-hidden flex items-center justify-center">
      <Suspense fallback={<div className="w-full h-full bg-black" />}>
        {/* We use a wrapper that shifts slightly on desktop to center relative to the main content area */}
        <div className="w-full h-full opacity-60 flex items-center justify-center lg:ml-32">
          <div className="w-full h-full min-w-[100vw] min-h-[100vh] flex items-center justify-center">
            <Spline 
              scene="https://prod.spline.design/yDE-LP5kwPt4yVU9/scene.splinecode" 
              className="w-full h-full"
              style={{ 
                filter: 'brightness(0.5) contrast(1.5) saturate(0.8) grayscale(0.5)',
                transform: 'scale(1.1)', 
              }}
            />
          </div>
        </div>
      </Suspense>
      
      {/* Heavy black vignette to isolate the robot */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,transparent_0%,rgba(0,0,0,0.95)_100%)] pointer-events-none" />
      
      {/* Bottom and side fades to ensure UI readability and focus */}
      <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-transparent to-black pointer-events-none" />
      <div className="absolute inset-y-0 left-0 w-32 bg-gradient-to-r from-black to-transparent pointer-events-none" />
      <div className="absolute inset-y-0 right-0 w-32 bg-gradient-to-l from-black to-transparent pointer-events-none" />
    </div>
  );
}
