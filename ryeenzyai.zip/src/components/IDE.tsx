import { useState, useEffect } from 'react';
import Editor from '@monaco-editor/react';
import { motion, AnimatePresence } from 'motion/react';
import { File, Folder, Plus, Trash2, Play, Save, ChevronRight, ChevronDown, X, Monitor, Code as CodeIcon } from 'lucide-react';
import { cn } from '../lib/utils';
import { auth, db } from '../firebase';
import { collection, query, onSnapshot, doc, setDoc, deleteDoc, updateDoc, serverTimestamp } from 'firebase/firestore';

interface ProjectFile {
  id: string;
  name: string;
  content: string;
  language: string;
}

import { User } from 'firebase/auth';
import { handleFirestoreError, OperationType } from '../lib/firestoreErrorHandler';

interface IDEProps {
  user: User;
}

export default function IDE({ user }: IDEProps) {
  const [files, setFiles] = useState<ProjectFile[]>([]);
  const [activeFileId, setActiveFileId] = useState<string | null>(null);
  const [previewContent, setPreviewContent] = useState('');
  const [showPreview, setShowPreview] = useState(false);
  const [isSidebarOpen, setIsSidebarOpen] = useState(window.innerWidth > 1024);

  const activeFile = files.find(f => f.id === activeFileId);

  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth <= 1024) setIsSidebarOpen(false);
      else setIsSidebarOpen(true);
    };
    window.addEventListener('resize', handleResize);
    
    // Load files from a default project for now
    const q = query(collection(db, 'users', user.uid, 'projects', 'default', 'files'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const loadedFiles = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as ProjectFile));
      setFiles(loadedFiles);
      if (loadedFiles.length > 0 && !activeFileId) {
        setActiveFileId(loadedFiles[0].id);
      }
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, `users/${user.uid}/projects/default/files`);
    });

    return () => {
      window.removeEventListener('resize', handleResize);
      unsubscribe();
    };
  }, [user.uid]);

  const createFile = async () => {
    const name = prompt('Enter file name (e.g. index.html):');
    if (!name) return;

    const extension = name.split('.').pop();
    let language = 'plaintext';
    if (extension === 'html') language = 'html';
    else if (extension === 'css') language = 'css';
    else if (extension === 'js') language = 'javascript';
    else if (extension === 'ts') language = 'typescript';

    const fileId = Math.random().toString(36).substr(2, 9);
    try {
      await setDoc(doc(db, 'users', user.uid, 'projects', 'default', 'files', fileId), {
        name,
        content: '',
        language,
        updatedAt: serverTimestamp()
      });
      
      // Update parent project document for History
      await setDoc(doc(db, 'users', user.uid, 'projects', 'default'), {
        name: 'PROJECT_DEFAULT',
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      }, { merge: true });

      setActiveFileId(fileId);
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, `users/${user.uid}/projects/default/files/${fileId}`);
    }
  };

  const deleteFile = async (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!confirm('Delete this file?')) return;
    try {
      await deleteDoc(doc(db, 'users', user.uid, 'projects', 'default', 'files', id));
      if (activeFileId === id) setActiveFileId(files.find(f => f.id !== id)?.id || null);
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `users/${user.uid}/projects/default/files/${id}`);
    }
  };

  const handleEditorChange = async (value: string | undefined) => {
    if (!activeFileId) return;
    try {
      await updateDoc(doc(db, 'users', user.uid, 'projects', 'default', 'files', activeFileId), {
        content: value || '',
        updatedAt: serverTimestamp()
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `users/${user.uid}/projects/default/files/${activeFileId}`);
    }
  };

  const runCode = () => {
    const html = files.find(f => f.name === 'index.html')?.content || '';
    const css = files.find(f => f.name === 'style.css')?.content || '';
    const js = files.find(f => f.name === 'script.js')?.content || '';

    const combined = `
      <html>
        <head>
          <style>${css}</style>
        </head>
        <body>
          ${html}
          <script>${js}</script>
        </body>
      </html>
    `;
    setPreviewContent(combined);
    setShowPreview(true);
  };

  return (
    <div className="h-full flex bg-[#0c0c0c] text-silver/90 overflow-hidden">
      {/* File Explorer Sidebar */}
      <motion.aside 
        initial={false}
        animate={{ width: isSidebarOpen ? 260 : 0 }}
        className="bg-[#111] border-r border-white/5 flex flex-col overflow-hidden"
      >
        <div className="p-4 flex items-center justify-between border-b border-white/5 shrink-0">
          <span className="text-xs font-bold uppercase tracking-widest text-silver/40">Explorer</span>
          <button onClick={createFile} className="p-1 hover:bg-white/5 rounded text-silver/60 hover:text-white">
            <Plus className="w-4 h-4" />
          </button>
        </div>
        
        <div className="flex-1 overflow-y-auto p-2 space-y-1 custom-scrollbar">
          <div className="flex items-center gap-2 px-2 py-1.5 text-xs font-semibold text-silver/60">
            <ChevronDown className="w-3 h-3" />
            <Folder className="w-3 h-3" />
            <span>PROJECT_DEFAULT</span>
          </div>
          
          {files.map(file => (
            <button
              key={file.id}
              onClick={() => setActiveFileId(file.id)}
              className={cn(
                "w-full flex items-center gap-2 px-6 py-1.5 rounded-md text-sm group transition-colors",
                activeFileId === file.id ? "bg-white/10 text-white" : "hover:bg-white/5 text-silver/60"
              )}
            >
              <File className="w-3.5 h-3.5" />
              <span className="flex-1 text-left truncate">{file.name}</span>
              <button 
                onClick={(e) => deleteFile(file.id, e)}
                className="opacity-0 group-hover:opacity-100 p-1 hover:text-red-400 transition-all"
              >
                <Trash2 className="w-3 h-3" />
              </button>
            </button>
          ))}
        </div>
      </motion.aside>

      {/* Main Editor Area */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Tabs */}
        <div className="flex bg-[#111] border-b border-white/5 overflow-x-auto no-scrollbar shrink-0">
          {files.map(file => (
            <button
              key={file.id}
              onClick={() => setActiveFileId(file.id)}
              className={cn(
                "flex items-center gap-2 px-4 py-2.5 border-r border-white/5 text-xs min-w-[120px] transition-colors relative",
                activeFileId === file.id ? "bg-[#1e1e1e] text-white" : "bg-[#111] text-silver/40 hover:bg-[#181818]"
              )}
            >
              <File className="w-3 h-3" />
              <span className="truncate">{file.name}</span>
              {activeFileId === file.id && (
                <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-accent" />
              )}
            </button>
          ))}
        </div>

        {/* Toolbar */}
        <div className="flex items-center justify-between px-4 py-2 bg-[#1e1e1e] border-b border-white/5 shrink-0">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2 text-[10px] text-silver/40 uppercase tracking-widest">
              <CodeIcon className="w-3 h-3" />
              <span>{activeFile?.language || 'No file selected'}</span>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button 
              onClick={() => setIsSidebarOpen(!isSidebarOpen)}
              className="lg:hidden p-1.5 hover:bg-white/5 rounded text-silver/40"
            >
              <Folder className="w-4 h-4" />
            </button>
            <button 
              onClick={runCode}
              className="flex items-center gap-2 px-3 py-1 bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 rounded-md text-xs hover:bg-emerald-500/20 transition-colors"
            >
              <Play className="w-3 h-3" />
              Run
            </button>
            <button className="p-1.5 hover:bg-white/5 rounded text-silver/40">
              <Save className="w-4 h-4" />
            </button>
            <button 
              onClick={() => setShowPreview(!showPreview)}
              className={cn(
                "p-1.5 rounded transition-colors",
                showPreview ? "bg-white/10 text-white" : "hover:bg-white/5 text-silver/40"
              )}
            >
              <Monitor className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Editor & Preview Split */}
        <div className="flex-1 flex overflow-hidden">
          <div className={cn("flex-1", showPreview && "border-r border-white/5")}>
            {activeFileId ? (
              <Editor
                height="100%"
                theme="vs-dark"
                language={activeFile?.language}
                value={activeFile?.content}
                onChange={handleEditorChange}
                options={{
                  fontSize: 14,
                  fontFamily: 'JetBrains Mono, monospace',
                  minimap: { enabled: false },
                  scrollBeyondLastLine: false,
                  automaticLayout: true,
                  padding: { top: 20 }
                }}
              />
            ) : (
              <div className="h-full flex flex-col items-center justify-center text-silver/20">
                <CodeIcon className="w-16 h-16 mb-4" />
                <p>Select a file to start coding</p>
              </div>
            )}
          </div>

          <AnimatePresence>
            {showPreview && (
              <motion.div 
                initial={{ width: 0, opacity: 0 }}
                animate={{ 
                  width: window.innerWidth > 1024 ? '40%' : '100%',
                  height: window.innerWidth > 1024 ? '100%' : '50%',
                  opacity: 1 
                }}
                exit={{ width: 0, opacity: 0 }}
                className={cn(
                  "bg-white flex flex-col overflow-hidden z-20",
                  window.innerWidth <= 1024 && "fixed inset-x-0 bottom-0 h-1/2 border-t border-white/10"
                )}
              >
                <div className="bg-[#111] p-2 flex items-center justify-between border-b border-white/5">
                  <span className="text-[10px] text-silver/40 uppercase tracking-widest px-2">Live Preview</span>
                  <button onClick={() => setShowPreview(false)} className="p-1 hover:bg-white/5 rounded text-silver/40">
                    <X className="w-3 h-3" />
                  </button>
                </div>
                <iframe
                  title="preview"
                  srcDoc={previewContent}
                  className="flex-1 w-full border-none bg-white"
                />
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}
