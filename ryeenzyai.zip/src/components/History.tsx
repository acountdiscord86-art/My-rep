import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Search, MessageSquare, Code, Trash2, Calendar, Clock, ChevronRight } from 'lucide-react';
import { auth, db } from '../firebase';
import { collection, query, orderBy, onSnapshot, deleteDoc, doc } from 'firebase/firestore';
import { cn } from '../lib/utils';

import { handleFirestoreError, OperationType } from '../lib/firestoreErrorHandler';

export default function History() {
  const [chats, setChats] = useState<any[]>([]);
  const [projects, setProjects] = useState<any[]>([]);
  const [activeType, setActiveType] = useState<'chats' | 'projects'>('chats');
  const [search, setSearch] = useState('');

  useEffect(() => {
    const user = auth.currentUser;
    if (!user) return;

    const chatsQ = query(collection(db, 'users', user.uid, 'chats'), orderBy('createdAt', 'desc'));
    const projectsQ = query(collection(db, 'users', user.uid, 'projects'), orderBy('createdAt', 'desc'));

    const unsubChats = onSnapshot(chatsQ, (snapshot) => {
      setChats(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, `users/${user.uid}/chats`);
    });

    const unsubProjects = onSnapshot(projectsQ, (snapshot) => {
      setProjects(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, `users/${user.uid}/projects`);
    });

    return () => {
      unsubChats();
      unsubProjects();
    };
  }, []);

  const deleteItem = async (id: string, type: 'chats' | 'projects') => {
    const user = auth.currentUser;
    if (!user || !confirm('Delete this from history?')) return;
    try {
      await deleteDoc(doc(db, 'users', user.uid, type, id));
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `users/${user.uid}/${type}/${id}`);
    }
  };

  const filteredItems = (activeType === 'chats' ? chats : projects).filter(item => 
    (item.title || item.name || '').toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="h-full p-4 md:p-8 overflow-y-auto custom-scrollbar">
      <div className="max-w-4xl mx-auto">
        <header className="mb-6 md:mb-8 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl md:text-3xl font-bold tracking-tight mb-2">History</h1>
            <p className="text-silver/40 text-xs md:text-sm">Manage your previous interactions and projects.</p>
          </div>
          <div className="flex bg-white/5 p-1 rounded-xl border border-white/10 self-start md:self-auto">
            <button
              onClick={() => setActiveType('chats')}
              className={cn(
                "px-4 py-2 rounded-lg text-sm font-medium transition-all",
                activeType === 'chats' ? "bg-white text-black" : "text-silver/60 hover:text-white"
              )}
            >
              Chats
            </button>
            <button
              onClick={() => setActiveType('projects')}
              className={cn(
                "px-4 py-2 rounded-lg text-sm font-medium transition-all",
                activeType === 'projects' ? "bg-white text-black" : "text-silver/60 hover:text-white"
              )}
            >
              Projects
            </button>
          </div>
        </header>

        <div className="relative mb-8">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-silver/40" />
          <input
            type="text"
            placeholder={`Search ${activeType}...`}
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full bg-white/5 border border-white/10 rounded-2xl py-4 pl-12 pr-4 text-white placeholder:text-silver/20 focus:outline-none focus:border-silver/40 transition-colors"
          />
        </div>

        <div className="space-y-4">
          {filteredItems.length === 0 ? (
            <div className="text-center py-20 opacity-20">
              <Clock className="w-16 h-16 mx-auto mb-4" />
              <p>No history found</p>
            </div>
          ) : (
            filteredItems.map((item, i) => (
              <motion.div
                key={item.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.05 }}
                className="group flex items-center gap-4 p-4 rounded-2xl bg-white/5 border border-white/10 hover:border-white/20 transition-all cursor-pointer"
              >
                <div className="w-12 h-12 rounded-xl bg-white/5 flex items-center justify-center shrink-0">
                  {activeType === 'chats' ? <MessageSquare className="w-5 h-5 text-blue-400" /> : <Code className="w-5 h-5 text-emerald-400" />}
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="font-semibold truncate">{item.title || item.name}</h3>
                  <div className="flex items-center gap-3 text-xs text-silver/40 mt-1">
                    <span className="flex items-center gap-1">
                      <Calendar className="w-3 h-3" />
                      {new Date(item.createdAt?.seconds * 1000 || item.createdAt).toLocaleDateString()}
                    </span>
                    {item.lastMessage && (
                      <span className="truncate max-w-[200px]">{item.lastMessage}</span>
                    )}
                  </div>
                </div>
                <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                  <button 
                    onClick={(e) => { e.stopPropagation(); deleteItem(item.id, activeType); }}
                    className="p-2 hover:bg-red-500/10 text-silver/40 hover:text-red-400 rounded-lg transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                  <ChevronRight className="w-4 h-4 text-silver/20" />
                </div>
              </motion.div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
