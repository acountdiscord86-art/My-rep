import { motion } from 'motion/react';
import ThreeBackground from './ThreeBackground';

interface LoadingScreenProps {
  theme?: string;
  type?: string;
  color?: string;
}

export default function LoadingScreen({ theme = 'silver', type = 'moon', color = '#ffffff' }: LoadingScreenProps) {
  return (
    <div className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-transparent text-white">
      <ThreeBackground type={type} color={color} />
      <div className="relative w-72 h-72 md:w-96 md:h-96 mb-8">
        {/* 3D-like scanning animation */}
        <motion.div
          animate={{
            rotate: 360,
            scale: [1, 1.05, 1],
          }}
          transition={{
            duration: 4,
            repeat: Infinity,
            ease: "linear",
          }}
          className="absolute inset-0 border-2 border-accent/20 rounded-full"
        />
        <motion.div
          animate={{
            rotate: -360,
            scale: [1, 1.1, 1],
          }}
          transition={{
            duration: 6,
            repeat: Infinity,
            ease: "linear",
          }}
          className="absolute inset-6 border-2 border-accent/40 rounded-full border-t-transparent"
        />
        <motion.div
          animate={{
            opacity: [0.5, 1, 0.5],
            scale: [0.98, 1.02, 0.98]
          }}
          transition={{
            duration: 3,
            repeat: Infinity,
            ease: "easeInOut"
          }}
          className="absolute inset-0 flex items-center justify-center p-12 md:p-16"
        >
          <img 
            src="https://www.image2url.com/r2/default/images/1776259988731-7cc679d1-4c75-4ec5-b335-ad5c748f0010.png" 
            alt="RyeenzyAI Logo" 
            className="w-full h-full object-contain drop-shadow-[0_0_30px_rgba(var(--accent-color),0.6)]"
            referrerPolicy="no-referrer"
          />
        </motion.div>
      </div>

      <div className="w-64 h-1 bg-white/10 rounded-full overflow-hidden relative">
        <motion.div
          initial={{ width: 0 }}
          animate={{ width: "100%" }}
          transition={{ duration: 2, ease: "easeInOut" }}
          className="h-full bg-gradient-to-r from-transparent via-accent to-transparent"
        />
      </div>
      
      <motion.p
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.5 }}
        className="mt-4 text-sm font-mono text-accent/60 uppercase tracking-[0.3em]"
      >
        Initializing AI System...
      </motion.p>
    </div>
  );
}
